module.exports = {
  extends: "next",
  rules: {},
};