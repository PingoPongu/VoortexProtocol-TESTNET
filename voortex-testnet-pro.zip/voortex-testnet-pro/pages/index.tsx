import React from 'react';
import TestnetPage from '../src/components/TestnetPage';

export default function Home() {
  return <TestnetPage />;
}
